//
//  colores.swift
//  hamburguesasMundo
//
//  Created by user114287 on 28/11/15.
//  Copyright © 2015 Romy Ocampo. All rights reserved.
//

import Foundation
import UIKit

struct Colores{
    let colores = [
        UIColor(red: 210/255, green: 77/255,  blue: 87/255,  alpha: 1.0),
        UIColor(red: 217/255, green: 30/255,  blue: 24/255,  alpha: 1.0),
        UIColor(red: 150/255, green: 40/255,  blue: 27/255,  alpha: 1.0),
        UIColor(red: 220/255, green: 198/255, blue: 224/255, alpha: 1.0),
        UIColor(red: 103/255, green: 65/255,  blue: 114/255, alpha: 1.0)
    ]
    func colorAleatorio() ->UIColor{
        let posicion = Int(arc4random()) % colores.count
        return colores[posicion]
    }
}
