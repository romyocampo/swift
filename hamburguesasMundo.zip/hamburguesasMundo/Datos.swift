//
//  Datos.swift
//  hamburguesasMundo
//
//  Created by user114287 on 28/11/15.
//  Copyright © 2015 Romy Ocampo. All rights reserved.
//

import Foundation

class ColeccionPaises{
    let coleccionPaises = [
        "Mexico",
        "Japon",
        "Turquia",
        "Espana",
        "Belgica",
        "Holanda",
        "Suiza",
        "Chile",
        "Noruega",
        "Peru",
        "Argentina",
        "Colombia",
        "China",
        "Sudafrica",
        "Italia",
        "Grecia",
        "Ecuador",
        "Cuba",
        "Uruguay",
        "Paraguay"
        ]
    func obtenPais( ) -> String{
        let posicion = Int(arc4random()) % coleccionPaises.count
    return coleccionPaises[posicion]
        
    }
}

class ColeccionHamburguesas{
    let coleccionHamburguesas = [
        "Hamburguesa Res Chilli Beans",
        "Hamburguesa Hawaiiana",
        "Hamburguesa Res Suprema",
        "Hamburguesa Pollo a las hierbas",
        "Hamburguesa Pollo con setas",
        "Hamburguesa Res con curri",
        "Hamburguesa Camaron con queso",
        "Hamburguesa Pollo Napolitano",
        "Hamburguesa Salmon",
        "Hamburguesa T'bone",
        "Hamburguesa Bolonesa",
        "Hamburguesa de Cordero",
        "Hamburguesa de Venado",
        "Hamburgueza Parrillada"
    ]
    func obtenHamburguesa( ) -> String{
        let posicion = Int(arc4random()) % coleccionHamburguesas.count
        return coleccionHamburguesas[posicion]
        
    }
}